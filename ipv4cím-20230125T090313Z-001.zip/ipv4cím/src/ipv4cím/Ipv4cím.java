/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ipv4cím;

import java.util.Scanner;

/**
 *
 * @author t1
 */
public class Ipv4cím {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
        System.out.print("ipv4 cím: ");
        String ipv4 = in.nextLine();
        String[] ipcímfelbont = ipv4.split("\\.");
        boolean betu =true;
        
        while (ipcímfelbont.length != 4 || betu) {
            System.out.println("Ez nem egy íp cím");
            System.out.print("ipv4 cím: ");
            ipv4 = in.nextLine();
            ipcímfelbont = ipv4.split("\\.");
            for (String string : ipcímfelbont) {
                int szam;
                try {
                    szam = Integer.valueOf(string);
                    betu = false;
                } catch (Exception e) {
                    betu = true;
                    break;
                }
            }
            if (betu) {
                continue;
            }
        }
        
        int szam = Integer.valueOf(ipcímfelbont[0]);
        if (szam <= 127) {
            System.out.println("Típus: A");
            System.out.println("Subnet Mask: 255.0.0.0");
            System.out.println("255.0.0.128");
        }
        else if (szam <= 191) {
            System.out.println("Típus: B");
            System.out.println("Subnet Mask:  255.255.0.0");
        }
        else if (szam <= 223) {
            System.out.println("Típus: C");
            System.out.println("Subnet Mask:  255.255.255.0 ");
            System.out.println("255.255.255.128");
        }    
        
    }
    
}
